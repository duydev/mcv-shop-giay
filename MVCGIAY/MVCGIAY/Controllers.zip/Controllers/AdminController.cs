﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCGIAY.Models;
using PagedList;
using PagedList.Mvc;
using System.IO;
namespace MVCGIAY.Controllers
{
    public class AdminController : Controller
    {
        dbQUANLYBANGIAYDataContext data = new dbQUANLYBANGIAYDataContext();
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Giay(int ?page)
        {
            int pageNumber = (page ?? 1);
            int pageSize = 7;
            return View(data.SANPHAMs.ToList().OrderBy(n=>n.MaSP).ToPagedList(pageNumber, pageSize));
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(FormCollection colletion)
        {
            var tendn = colletion["username"];
            var matkhau = colletion["password"];
            if (String.IsNullOrEmpty(tendn))
            {
                ViewData["Loi1"] = "Phải nhập tên đăng nhập";
            }
            else if (String.IsNullOrEmpty(matkhau))
            {
                ViewData["Loi2"] = "Phải nhập mật khẩu";
            }
            else
            {
                ADMIN ad = data.ADMINs.SingleOrDefault(n => n.UserName == tendn && n.PassWord == matkhau);
                if (ad != null)
                {
                    Session["Taikhoanadmin"] = ad;
                    return RedirectToAction("Index","Admin");
                }
                else
                    ViewBag.Thongbao = "Tên đăng nhập hoặc mật khẩu không đúng";
            }
            return View();
        }
        [HttpGet]
        public ActionResult Themmoigiay()
        {
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Themmoigiay(SANPHAM giay, HttpPostedFileBase fileupload)
        {
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            if(fileupload == null)
            {
                ViewBag.Thongbao = "Vui lòng chọn ảnh bìa";
                return View();
            }
            //them vao csdl
            else
            {
                if (ModelState.IsValid)
                {
                    var fileName = Path.GetFileName(fileupload.FileName);
                    var path = Path.Combine(Server.MapPath("~/images/home"), fileName);
                    if (System.IO.File.Exists(path))
                        ViewBag.Thongbao = "Hình ảnh đã tồn tại";
                    else
                    {
                        fileupload.SaveAs(path);
                    }
                    giay.Anh = fileName;
                    data.SANPHAMs.InsertOnSubmit(giay);
                    data.SubmitChanges();
                }
            }
            return RedirectToAction("Giay");
        }
        public ActionResult Chitietgiay(int id)
        {
            //lay giay theo ma
            SANPHAM giay = data.SANPHAMs.SingleOrDefault(n => n.MaSP == id);
            ViewBag.MaSP = giay.MaSP;
            if (giay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(giay);
        }
        [HttpGet]
        public ActionResult Xoagiay(int id)
        {
            //lay sp muốn xoa theo ma
            SANPHAM giay = data.SANPHAMs.SingleOrDefault(n => n.MaSP == id);
            ViewBag.MaSP = giay.MaSP;
            if (giay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(giay);
        }
        [HttpPost, ActionName("Xoagiay")]
        public ActionResult Xacnhanxoa(int id)
        {
            SANPHAM giay = data.SANPHAMs.SingleOrDefault(n => n.MaSP == id);
            ViewBag.MaSP = giay.MaSP;
            if (giay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            data.SANPHAMs.DeleteOnSubmit(giay);
            data.SubmitChanges();
            return RedirectToAction("Giay");
        }
        [HttpGet]
        public ActionResult Suagiay(int id)
        {
            SANPHAM giay = data.SANPHAMs.SingleOrDefault(n => n.MaSP == id);
            
            if (giay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            return View(giay);
        }
        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateInput(false)]
        public ActionResult Suagiay(int id, SANPHAM giay, HttpPostedFileBase fileUpload, FormCollection collection)
        {   
            //lấy dữ liệu từ dropdowmlist
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            var sp = data.SANPHAMs.SingleOrDefault(n => n.MaSP == id);
            try
            {
                UpdateModel(sp);
                data.SubmitChanges();
                return RedirectToAction("Giay");
            }
            catch
            {
                return View(sp);
            }
        }
        //////////////////////////////////////
        public ActionResult LoaiGiay(int? page)
        {
            int pageNumber = (page ?? 1);
            int pageSize = 7;
            return View(data.LOAIs.ToList().OrderBy(n => n.MaLoai).ToPagedList(pageNumber, pageSize));
        }
        public ActionResult Themloai()
        {
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Themloai(LOAI loaigiay, HttpPostedFileBase fileupload)
        {
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            return RedirectToAction("Giay");
        }
        [HttpGet]
        public ActionResult Xoaloai(int id)
        {
            //lay sp muốn xoa theo ma
            LOAI loaigiay = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            ViewBag.MaLoai = loaigiay.MaLoai;
            if (loaigiay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(loaigiay);
        }
        [HttpPost, ActionName("Xoagiay")]
        public ActionResult XNxoaloaigiay(int id)
        {
            LOAI loaigiay = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            ViewBag.MaLoai = loaigiay.MaLoai;
            if (loaigiay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            data.LOAIs.DeleteOnSubmit(loaigiay);
            data.SubmitChanges();
            return RedirectToAction("Giay");
        }
        [HttpGet]
        public ActionResult Sualoaigiay(int id)
        {
            LOAI loaigiay = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);

            if (loaigiay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            return View(loaigiay);
        }
        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateInput(false)]
        public ActionResult Sualoaigiay(int id, SANPHAM giay, HttpPostedFileBase fileUpload, FormCollection collection)
        {
            //lấy dữ liệu từ dropdowmlist
            ViewBag.MaNCC = new SelectList(data.NHACCs.ToList().OrderBy(n => n.TenNNC), "MaNCC", "TenNCC");
            var lsp = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            try
            {
                UpdateModel(lsp);
                data.SubmitChanges();
                return RedirectToAction("Giay");
            }
            catch
            {
                return View(lsp);
            }
        }
    }
}